//============================================================================
// Name        : NTFSTest.cpp
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include "NTFS_Common.h"
#include "CNTFSVolume.h"

int main() {
    CNTFSVolume volume(_T('C'));
    return 0;
}
