/*
 * NTFS_Attribute.h
 *
 *  Created on: Nov 4, 2020
 *      Author: wade4
 */

#ifndef NTFS_ATTRIBUTE_H_
#define NTFS_ATTRIBUTE_H_

typedef class CSList<CIndexEntry> CIndexEntryList;

#endif /* NTFS_ATTRIBUTE_H_ */
